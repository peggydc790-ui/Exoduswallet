-- Starter schema for £xodus.wallet demo environment.
-- Run in Supabase SQL Editor. Balances are simulated and have no cash value.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table if not exists public.demo_wallets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  name text not null default 'Main wallet',
  asset_code text not null check (asset_code in ('BTC','ETH','USDT','USDC','SOL')),
  demo_balance numeric(24,8) not null default 0 check (demo_balance >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.demo_transactions (
  id uuid primary key default gen_random_uuid(),
  sender_wallet_id uuid references public.demo_wallets(id),
  recipient_wallet_id uuid references public.demo_wallets(id),
  sender_user_id uuid references auth.users(id),
  recipient_user_id uuid references auth.users(id),
  asset_code text not null check (asset_code in ('BTC','ETH','USDT','USDC','SOL')),
  amount numeric(24,8) not null check (amount > 0),
  status text not null default 'completed' check (status in ('completed','reversed')),
  reference text not null unique default ('DEMO-' || upper(substr(replace(gen_random_uuid()::text,'-',''),1,12))),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.demo_wallets enable row level security;
alter table public.demo_transactions enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile" on public.profiles for select using (auth.uid() = id);
drop policy if exists "Users can update own profile" on public.profiles;
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id);

drop policy if exists "Users can read own demo wallets" on public.demo_wallets;
create policy "Users can read own demo wallets" on public.demo_wallets for select using (auth.uid() = user_id);

drop policy if exists "Users can read own demo transactions" on public.demo_transactions;
create policy "Users can read own demo transactions" on public.demo_transactions for select
using (auth.uid() = sender_user_id or auth.uid() = recipient_user_id);

-- Deliberately no browser insert/update policies for wallet balances or transactions.
-- A secure server-side transfer function and admin authorization must be added
-- before enabling wallet funding, balance adjustments, or transfers.
